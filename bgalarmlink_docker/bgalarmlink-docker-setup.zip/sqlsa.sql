sp_password @new='1Password', @loginame='sa'
go
ALTER LOGIN [sa] ENABLE
go