ALTER TABLE AlarmInstance MODIFY level1view text;
ALTER TABLE AlarmInstance MODIFY level2view text;
