-------------------------------------------------------------------------------
-- 
-- Project 0000000, SzH 30.03.2006
--
-------------------------------------------------------------------------------
-- This scripts creates a procedure 'MakeBackup' and an event 'Backup' in the database 
-- to create a backup of the database 
-- Additional the transaction log file is truncated by the procedure.
-------------------------------------------------------------------------------
-- change:  05.07.2012,RJB, Replaced '\\' by '\' otherwise script mail fail (the very first time?)
-- 
-------------------------------------------------------------------------------

go
-------------------------------------------------
--   Delete procedure
-------------------------------------------------
if exists (select * from SysProcedure where proc_name='MakeBackup') then
    message 'Delete procedure: MakeBackup';
    drop procedure "MakeBackup"
end if
go

-------------------------------------------------
--   Create procedures
-------------------------------------------------

setuser "DBA" 
go

create procedure DBA.MakeBackup() 
begin
  /* Get current database directory */
  declare sPath varchar(255);
  declare lPos integer;
  select db_property('File') into sPath; /*db_property contains info of database*/
  set lpos=locate(sPath,'\',-1);
  set sPath=substr(sPath,1,lpos-1);
  set sPath=sPath+'\BackupDir';
  /* Create backup in subdirectory and truncate transaction log file */
  backup database directory sPath transaction log truncate wait before start wait after end
  
end
go
COMMENT ON PROCEDURE "DBA"."MakeBackup" IS 
	'Create backup in subdirectory BackupDir V.30.03.2006'
go
call dbo.sa_recompile_views(0)
go

commit work
go



-------------------------------------------------
--   Delete event
-------------------------------------------------
if exists (select * from SysEvent where event_name='Backup') then
    message 'Delete Event: Backup';
    drop event "Backup"
end if
go

-------------------------------------------------
--   Create events
-------------------------------------------------

CREATE EVENT "Backup" TYPE "GrowLog" WHERE event_condition('LogSize') >= 3000 ENABLE AT ALL 
HANDLER
begin
  call MakeBackup()
end
go
COMMENT ON EVENT "Backup" IS 
	'This event is raised in the size of the transaction log increases  3GB. V 30.06.2006'
go

commit work
go