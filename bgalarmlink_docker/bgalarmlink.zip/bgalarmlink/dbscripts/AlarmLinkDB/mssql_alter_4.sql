/* 1) Rename AlarmIdentification db to AlarmIdentification_copy
   2) Create new AlarmIdentification db
   3) Copy data from old table to new
   4) Drop old table */


EXEC sp_rename 'AlarmIdentification', 'AlarmIdentification_copy'
GO
CREATE TABLE AlarmIdentification(
	[alarmtag] [nvarchar](390) NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[value] [nvarchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Index [GetAlarmIdentificationsIndex]    Script Date: 24-06-2016 10:28:09 ******/
CREATE NONCLUSTERED INDEX [GetAlarmIdentificationsIndex] ON [dbo].[AlarmIdentification]
(
	[alarmtag] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

/****** Object:  Index [UpdateAlarmIdentificationsIndex]    Script Date: 24-06-2016 10:29:18 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UpdateAlarmIdentificationsIndex] ON [dbo].[AlarmIdentification]
(
	[alarmtag] ASC,
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

declare @sql varchar(1000)   
set @sql = 'INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, ''Comment'', alarmcomment from AlarmIdentification_copy'
Exec (@sql)
Go
declare @sql varchar(1000)   
set @sql = 'INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, ''InhibitState'', ''ProcessAndDisplay'' from AlarmIdentification_copy WHERE status = 1'
Exec (@sql)
set @sql = 'INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, ''InhibitState'', ''ProcessedButNotVisible'' from AlarmIdentification_copy WHERE status = 2'
Exec (@sql)
set @sql = 'INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, ''InhibitState'', ''NotProcessedAndNotVisible'' from AlarmIdentification_copy WHERE status = 3'
Exec (@sql)
Go
DROP TABLE AlarmIdentification_copy
GO

