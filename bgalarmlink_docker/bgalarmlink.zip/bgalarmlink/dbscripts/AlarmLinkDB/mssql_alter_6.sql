
Alter table [dbo].[Alarminstance] Alter Column category nvarchar(50)

CREATE NONCLUSTERED INDEX [_index_AlarmInstance_Category] ON [dbo].[AlarmInstance]
(
	[category] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO