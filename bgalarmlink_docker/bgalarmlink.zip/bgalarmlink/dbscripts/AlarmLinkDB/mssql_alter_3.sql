/* Create ExtendedProperties and ReplacementValues table if not exists */
/* Copy data fra AlarmInstance if exists into new tables */
/* Drop old AlarmInstance columns */

declare @sql varchar(1000)   

IF object_id('ExtendedProperties') is null
BEGIN
CREATE TABLE [dbo].[ExtendedProperties](
	[alarmtag] [nvarchar](390) NOT NULL,
	[dateon] [datetime2] NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[value] [nvarchar](max) NULL
) ON [PRIMARY] 

/****** Object:  Index [GetExtendedPropertiesIndex]    Script Date: 24-06-2016 10:28:09 ******/
CREATE NONCLUSTERED INDEX [GetExtendedPropertiesIndex] ON [dbo].[ExtendedProperties]
(
	[alarmtag] ASC,
	[dateon] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

/****** Object:  Index [UpdateExtendedPropertyIndex]    Script Date: 24-06-2016 10:29:18 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UpdateExtendedPropertyIndex] ON [dbo].[ExtendedProperties]
(
	[alarmtag] ASC,
	[dateon] ASC,
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ExtendedProperty1')
BEGIN
   set @sql = 'INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty1", extendedproperty1 from AlarmInstance where extendedproperty1 is not NULL AND extendedproperty1 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ExtendedProperty1
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ExtendedProperty2')
BEGIN
   set @sql = 'INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty2", extendedproperty2 from AlarmInstance where extendedproperty2 is not NULL AND extendedproperty2 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ExtendedProperty2
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ExtendedProperty3')
BEGIN
   set @sql = 'INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty3", extendedproperty3 from AlarmInstance where extendedproperty3 is not NULL AND extendedproperty3 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ExtendedProperty3
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ExtendedProperty4')
BEGIN
   set @sql = 'INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty4", extendedproperty4 from AlarmInstance where extendedproperty4 is not NULL AND extendedproperty4 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ExtendedProperty4
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ExtendedProperty5')
BEGIN
   set @sql = 'INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty5", extendedproperty5 from AlarmInstance where extendedproperty5 is not NULL AND extendedproperty5 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ExtendedProperty5
END

END


IF object_id('ReplacementValues') is null
BEGIN
CREATE TABLE [dbo].[ReplacementValues](
	[alarmtag] [nvarchar](390) NOT NULL,
	[dateon] [datetime2] NOT NULL,
	[name] [nvarchar](50) NOT NULL,
	[value] [nvarchar](max) NULL
) ON [PRIMARY] 

/****** Object:  Index [GetReplacementValuesIndex]    Script Date: 24-06-2016 10:30:08 ******/
CREATE NONCLUSTERED INDEX [GetReplacementValuesIndex] ON [dbo].[ReplacementValues]
(
	[alarmtag] ASC,
	[dateon] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

/****** Object:  Index [UpdateReplacementValueIndex]    Script Date: 24-06-2016 10:30:20 ******/
CREATE UNIQUE NONCLUSTERED INDEX [UpdateReplacementValueIndex] ON [dbo].[ReplacementValues]
(
	[alarmtag] ASC,
	[dateon] ASC,
	[name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]

IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue1')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue1", ReplaceValue1 from AlarmInstance where ReplaceValue1 is not NULL AND ReplaceValue1 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue1
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue2')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue2", ReplaceValue2 from AlarmInstance where ReplaceValue2 is not NULL AND ReplaceValue2 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue2
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue3')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue3", ReplaceValue3 from AlarmInstance where ReplaceValue3 is not NULL AND ReplaceValue3 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue3
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue4')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue4", ReplaceValue4 from AlarmInstance where ReplaceValue4 is not NULL AND ReplaceValue4 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue4
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue5')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue5", ReplaceValue5 from AlarmInstance where ReplaceValue5 is not NULL AND ReplaceValue5 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue5
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue6')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue6", ReplaceValue6 from AlarmInstance where ReplaceValue6 is not NULL AND ReplaceValue6 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue6
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue7')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue7", ReplaceValue7 from AlarmInstance where ReplaceValue7 is not NULL AND ReplaceValue7 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue7
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue8')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue8", ReplaceValue8 from AlarmInstance where ReplaceValue8 is not NULL AND ReplaceValue8 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue8
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue9')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue9", ReplaceValue9 from AlarmInstance where ReplaceValue9 is not NULL AND ReplaceValue9 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue9
END
IF EXISTS(SELECT 1 FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'AlarmInstance' AND COLUMN_NAME = 'ReplaceValue10')
BEGIN
   set @sql = 'INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue10", ReplaceValue10 from AlarmInstance where ReplaceValue10 is not NULL AND ReplaceValue10 != '''''
   Exec (@sql)
   ALTER TABLE AlarmInstance DROP COLUMN ReplaceValue10
END

END


/* Convert datetime columns to datetime2 to solve precision issue */

DROP INDEX [_index_AlarmInstance_DateOn] ON [dbo].[AlarmInstance] WITH ( ONLINE = OFF )
GO
ALTER TABLE AlarmInstance ALTER column dateon datetime2
GO
CREATE CLUSTERED INDEX [_index_AlarmInstance_DateOn] ON [dbo].[AlarmInstance]
(
	[dateon] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO

ALTER TABLE AlarmInstance ALTER column dateoff datetime2
ALTER TABLE AlarmInstance ALTER column dateack datetime2

