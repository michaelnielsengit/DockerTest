Alter table Alarminstance modify category varchar(50)

CREATE NONCLUSTERED INDEX _index_AlarmInstance_Category ON AlarmInstance
(
	category  DESC
)
GO