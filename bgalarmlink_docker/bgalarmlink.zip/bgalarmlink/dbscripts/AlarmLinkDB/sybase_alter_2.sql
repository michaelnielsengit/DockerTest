ALTER TABLE AlarmEscalationPlan DROP CONSTRAINT PK_AlarmEscalationPlan;
ALTER TABLE AlarmEscalationPlan MODIFY alarmtag nvarchar(400) NOT NULL;
ALTER TABLE AlarmEscalationPlan ADD CONSTRAINT PK_AlarmEscalationPlan PRIMARY KEY CLUSTERED 
(
	alarmtag ASC
)
ALTER TABLE AlarmIdentification MODIFY alarmtag nvarchar(400) NOT NULL;
ALTER TABLE AlarmInstance MODIFY alarmtag nvarchar(400) NOT NULL;
