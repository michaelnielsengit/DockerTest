ALTER TABLE AlarmInstance ALTER COLUMN level1view nvarchar(max);
ALTER TABLE AlarmInstance ALTER COLUMN level2view nvarchar(max);
