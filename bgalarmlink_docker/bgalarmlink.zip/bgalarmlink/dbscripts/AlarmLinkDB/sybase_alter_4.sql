/* 1) Rename AlarmIdentification db to AlarmIdentification_copy
   2) Create new AlarmIdentification db
   3) Copy data from old table to new
   4) Drop old table */

ALTER TABLE AlarmIdentification RENAME AlarmIdentification_copy

CREATE TABLE AlarmIdentification(
	alarmtag nvarchar(390) NOT NULL,
	name nvarchar(50) NOT NULL,
	value nvarchar(4000) NULL
)

/****** Object:  Index [GetAlarmIdentificationsIndex]    Script Date: 24-06-2016 10:28:09 ******/
CREATE NONCLUSTERED INDEX GetAlarmIdentificationsIndex ON AlarmIdentification
(
	alarmtag ASC
)

/****** Object:  Index [UpdateAlarmIdentificationsIndex]    Script Date: 24-06-2016 10:29:18 ******/
CREATE UNIQUE NONCLUSTERED INDEX UpdateAlarmIdentificationsIndex ON AlarmIdentification
(
	alarmtag ASC,
	name ASC
)

--INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, 'Comment', alarmcomment from AlarmIdentification_copy
INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, 'InhibitState', 'ProcessAndDisplay' from AlarmIdentification_copy WHERE status = 1
INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, 'InhibitState', 'ProcessedButNotVisible' from AlarmIdentification_copy WHERE status = 2
INSERT INTO AlarmIdentification (alarmtag, name, value) SELECT alarmtag, 'InhibitState', 'NotProcessedAndNotVisible' from AlarmIdentification_copy WHERE status = 3

DROP TABLE AlarmIdentification_copy
