/* 1) Add 16 replacementvalue columns to AlarmInstance db
   2) Copy replacement values from old table to new columns
   3) Drop old table */
   
Alter table [dbo].[Alarminstance] ADD replacevalue1 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue2 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue3 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue4 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue5 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue6 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue7 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue8 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue9 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue10 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue11 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue12 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue13 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue14 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue15 nvarchar(200)
Alter table [dbo].[Alarminstance] ADD replacevalue16 nvarchar(200)
GO
UPDATE [dbo].[Alarminstance] set replacevalue1 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '1')
UPDATE [dbo].[Alarminstance] set replacevalue2 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '2')
UPDATE [dbo].[Alarminstance] set replacevalue3 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '3')
UPDATE [dbo].[Alarminstance] set replacevalue4 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '4')
UPDATE [dbo].[Alarminstance] set replacevalue5 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '5')
UPDATE [dbo].[Alarminstance] set replacevalue6 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '6')
UPDATE [dbo].[Alarminstance] set replacevalue7 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '7')
UPDATE [dbo].[Alarminstance] set replacevalue8 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '8')
UPDATE [dbo].[Alarminstance] set replacevalue9 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '9')
UPDATE [dbo].[Alarminstance] set replacevalue10 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '10')
UPDATE [dbo].[Alarminstance] set replacevalue11 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '11')
UPDATE [dbo].[Alarminstance] set replacevalue12 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '12')
UPDATE [dbo].[Alarminstance] set replacevalue13 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '13')
UPDATE [dbo].[Alarminstance] set replacevalue14 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '14')
UPDATE [dbo].[Alarminstance] set replacevalue15 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '15')
UPDATE [dbo].[Alarminstance] set replacevalue16 = (SELECT value from ReplacementValues as rv WHERE [dbo].[Alarminstance].alarmtag = rv.alarmtag AND [dbo].[Alarminstance].dateon = rv.dateon AND rv.name = '16')
GO
DROP TABLE ReplacementValues
GO