/* 1) Add 16 replacementvalue columns to AlarmInstance db
   2) Copy replacement values from old table to new columns
   3) Drop old table */

Alter table Alarminstance ADD replacevalue1 varchar(200)
Alter table Alarminstance ADD replacevalue2 varchar(200)
Alter table Alarminstance ADD replacevalue3 varchar(200)
Alter table Alarminstance ADD replacevalue4 varchar(200)
Alter table Alarminstance ADD replacevalue5 varchar(200)
Alter table Alarminstance ADD replacevalue6 varchar(200)
Alter table Alarminstance ADD replacevalue7 varchar(200)
Alter table Alarminstance ADD replacevalue8 varchar(200)
Alter table Alarminstance ADD replacevalue9 varchar(200)
Alter table Alarminstance ADD replacevalue10 varchar(200)
Alter table Alarminstance ADD replacevalue11 varchar(200)
Alter table Alarminstance ADD replacevalue12 varchar(200)
Alter table Alarminstance ADD replacevalue13 varchar(200)
Alter table Alarminstance ADD replacevalue14 varchar(200)
Alter table Alarminstance ADD replacevalue15 varchar(200)
Alter table Alarminstance ADD replacevalue16 varchar(200)
GO
UPDATE Alarminstance set replacevalue1 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '1')
UPDATE Alarminstance set replacevalue2 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '2')
UPDATE Alarminstance set replacevalue3 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '3')
UPDATE Alarminstance set replacevalue4 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '4')
UPDATE Alarminstance set replacevalue5 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '5')
UPDATE Alarminstance set replacevalue6 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '6')
UPDATE Alarminstance set replacevalue7 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '7')
UPDATE Alarminstance set replacevalue8 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '8')
UPDATE Alarminstance set replacevalue9 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '9')
UPDATE Alarminstance set replacevalue10 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '10')
UPDATE Alarminstance set replacevalue11 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '11')
UPDATE Alarminstance set replacevalue12 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '12')
UPDATE Alarminstance set replacevalue13 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '13')
UPDATE Alarminstance set replacevalue14 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '14')
UPDATE Alarminstance set replacevalue15 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '15')
UPDATE Alarminstance set replacevalue16 = (SELECT value from ReplacementValues as rv WHERE Alarminstance.alarmtag = rv.alarmtag AND Alarminstance.dateon = rv.dateon AND rv.name = '16')
GO
DROP TABLE ReplacementValues
GO