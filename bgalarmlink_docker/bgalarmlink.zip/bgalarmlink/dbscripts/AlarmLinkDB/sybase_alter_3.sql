/* Create ExtendedProperties and ReplacementValues table if not exists */
/* Copy data fra AlarmInstance if exists into new tables */
/* Drop old AlarmInstance columns */

declare @sql varchar(1000)   

if object_id('ExtendedProperties') is NULL
BEGIN
CREATE TABLE ExtendedProperties(
	alarmtag nvarchar(390) NOT NULL,
	dateon datetime NOT NULL,
	name nvarchar(50) NOT NULL,
	value text NULL
) 

/****** Object:  Index [GetExtendedPropertiesIndex]    Script Date: 24-06-2016 10:28:09 ******/
CREATE NONCLUSTERED INDEX GetExtendedPropertiesIndex ON ExtendedProperties
(
	alarmtag ASC,
	dateon ASC
)

/****** Object:  Index [UpdateExtendedPropertyIndex]    Script Date: 24-06-2016 10:29:18 ******/
CREATE UNIQUE NONCLUSTERED INDEX UpdateExtendedPropertyIndex ON ExtendedProperties
(
	alarmtag ASC,
	dateon ASC,
	name ASC
)


IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ExtendedProperty1')
BEGIN
   INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty1", extendedproperty1 from AlarmInstance where extendedproperty1 is not NULL AND extendedproperty1 != ''
   
   ALTER TABLE AlarmInstance DROP  ExtendedProperty1
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ExtendedProperty2')
BEGIN
   INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty2", extendedproperty2 from AlarmInstance where extendedproperty2 is not NULL AND extendedproperty2 != ''

   ALTER TABLE AlarmInstance DROP  ExtendedProperty2
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ExtendedProperty3')
BEGIN
   INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty3", extendedproperty3 from AlarmInstance where extendedproperty3 is not NULL AND extendedproperty3 != ''
   
   ALTER TABLE AlarmInstance DROP  ExtendedProperty3
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ExtendedProperty4')
BEGIN
   INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty4", extendedproperty4 from AlarmInstance where extendedproperty4 is not NULL AND extendedproperty4 != ''
 
   ALTER TABLE AlarmInstance DROP  ExtendedProperty4
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ExtendedProperty5')
BEGIN
   INSERT INTO ExtendedProperties (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ExtendedProperty5", extendedproperty5 from AlarmInstance where extendedproperty5 is not NULL AND extendedproperty5 != ''

   ALTER TABLE AlarmInstance DROP  ExtendedProperty5
END

END

if object_id('ReplacementValues') is NULL
BEGIN
CREATE TABLE ReplacementValues(
	alarmtag nvarchar(390) NOT NULL,
	dateon datetime NOT NULL,
	name nvarchar(50) NOT NULL,
	value text NULL
) 

/****** Object:  Index [GetReplacementValuesIndex]    Script Date: 24-06-2016 10:30:08 ******/
CREATE NONCLUSTERED INDEX GetReplacementValuesIndex ON ReplacementValues
(
	alarmtag ASC,
	dateon ASC
)

/****** Object:  Index [UpdateReplacementValueIndex]    Script Date: 24-06-2016 10:30:20 ******/
CREATE UNIQUE NONCLUSTERED INDEX UpdateReplacementValueIndex ON ReplacementValues
(
	alarmtag ASC,
	dateon ASC,
	name ASC
)

IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue1')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue1", ReplaceValue1 from AlarmInstance where ReplaceValue1 is not NULL AND ReplaceValue1 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue1
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue2')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue2", ReplaceValue2 from AlarmInstance where ReplaceValue2 is not NULL AND ReplaceValue2 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue2
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue3')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue3", ReplaceValue3 from AlarmInstance where ReplaceValue3 is not NULL AND ReplaceValue3 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue3
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue4')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue4", ReplaceValue4 from AlarmInstance where ReplaceValue4 is not NULL AND ReplaceValue4 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue4
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue5')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue5", ReplaceValue5 from AlarmInstance where ReplaceValue5 is not NULL AND ReplaceValue5 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue5
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue6')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue6", ReplaceValue6 from AlarmInstance where ReplaceValue6 is not NULL AND ReplaceValue6 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue6
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue7')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue7", ReplaceValue7 from AlarmInstance where ReplaceValue7 is not NULL AND ReplaceValue7 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue7
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue8')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue8", ReplaceValue8 from AlarmInstance where ReplaceValue8 is not NULL AND ReplaceValue8 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue8
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue9')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue9", ReplaceValue9 from AlarmInstance where ReplaceValue9 is not NULL AND ReplaceValue9 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue9
END
IF EXISTS(SELECT 1 FROM sys.syscolumns WHERE TNAME = 'AlarmInstance' AND CNAME = 'ReplaceValue10')
BEGIN
   INSERT INTO ReplacementValues (alarmtag, dateon, name, value) SELECT alarmtag, dateon, "ReplaceValue10", ReplaceValue10 from AlarmInstance where ReplaceValue10 is not NULL AND ReplaceValue10 != ''
   
   ALTER TABLE AlarmInstance DROP  ReplaceValue10
END
END


